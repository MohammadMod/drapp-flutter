const int limit = 20;
const duration_20 = Duration(seconds: 20);
const duration_60 = Duration(seconds: 60);
const duration_120 = Duration(seconds: 120);

///Production server
const api = "185.213.25.86:7147";

const String apiUrl = "http://$api";
